# Handoff: neeshdle — game UI (bare-bones layout spec)

## Overview
`neeshdle` is a Heardle-style guessing game built on the Spotify Web Playback SDK
(repo: `lyl4cs/neeshdle`, branch `main`). A track is picked from a Spotify playlist;
the player hears progressively longer clips (0.5s → 2s → 8s → full) and guesses the
song via a search box. Lifetime stats live in `localStorage`, keyed by Spotify user id.

This bundle is a **layout/structure spec** for the UI: where the stats button goes,
where the guessing terminal goes, how the clip slots read, what the reveal card
contains. The current app renders all of this with unstyled default markup; this
gives it a centered, coherent shell.

## About the Design Files
`Neeshdle Mockup.dc.html` is a **design reference created in HTML** — a static
prototype of the intended look and structure, not production code to copy.
The task is to recreate these layouts inside the existing codebase
(React 19 + Vite, plain CSS in `src/index.css`) using its established patterns.
Do not port the mockup's inline styles verbatim — translate them into
`src/index.css` classes matching the class names already used in `src/App.jsx`
(`.app`, `.slots`, `.actions`, `.results`, `.history`, `.stats-panel`,
`.playlist-bar`, `.playlist-switcher`, `.result-overlay`, `.result-card`).
`support.js` is only the runtime that makes the mockup file open in a browser —
it is not part of the deliverable.

## Fidelity
**Low-to-mid fidelity.** Structure, hierarchy, and state colors are intentional and
should be followed. Exact px values are reasonable defaults, not final. Final visual
design (type, texture, motion, branding) is still open — the user said they'd handle
design later. Treat spacing/rounding as guidance, not gospel.

## Screens / Views

### 1a — Main round (primary screen)
Purpose: play a clip, guess or skip, see attempt history.
Layout: a single centered column, max width ~640px, on `#111` with a `1px #262626`
border and 12px radius. Two regions:

**Header** — `display:flex; justify-content:space-between; padding:18px 24px;`
bottom border `1px #1e1e1e`.
- Left: 26px logo square (placeholder, see Assets) + wordmark `neeshdle`,
  700 18px, `letter-spacing:-.02em`.
- Right: pill buttons in a `gap:8px` flex row — **Stats** (`#eee` text) and
  **Playlist** (`#aaa` text). Both `padding:7px 14px`, `background:#1a1a1a`,
  `1px #333`, `border-radius:999px`, 500 13px.
  Stats toggles the stats panel (1b); Playlist toggles the switcher (1d).

**Body** — `display:flex; flex-direction:column; align-items:center; gap:22px;
padding:30px 24px 34px`. In order top to bottom:

1. **Playlist chip** — pill (`#161616`, `1px #282828`, radius 999) containing a
   30px round album thumb, playlist name (600 13px) and track count (mono 11px `#666`).
   Sourced from `fetchPlaylistMeta` (`playlistInfo.name`, `thumbnailUrl`).
2. **Clip slots** — a `gap:10px` row of four 52px squares, radius 8px, mono 700 15px,
   one per entry in `STAGES` (`src/config.js`). Below each, a mono 10px caption with
   the stage duration (`0.5s`, `2s`, `8s`, `full`). Slot states (from `src/index.css`):
   - empty: `background:#111`, border `1px #444`, text `#666`
   - current: `background:#111`, border `2px #1db954`, text `#fff`,
     plus `box-shadow:0 0 0 4px rgba(29,185,84,.12)`
   - wrong: `background:#b91c1c`, border `1px #b91c1c`, text `#fff`
   - skip: `background:#3a3a3a`, border `1px #555`, text `#ccc`
   - correct: `background:#1db954`, border `1px #1db954`, text `#111`
   The caption under the current slot is `#1db954`; the others `#555`.
3. **Clip label** — 700 15px, e.g. `Clip 3 of 4 — 8s`. Over states read
   `You got it — play the full track` / `Out of guesses — play the answer`
   (strings already in `src/App.jsx`).
4. **Transport** — a 74px circular primary button (`#1db954`, text `#0b0b0b`,
   mono 700 12px) labeled PLAY, and beside it a ghost pill `Skip →`
   (transparent, `1px #444`, `#aaa`). Disabled while `busy`; label becomes
   `Playing…`, and `Play song` once the round is over. Skip is hidden when over.
5. **Clip progress bar** — 420×34, `#161616`, `1px #242424`, radius 6.
   A filled region from the left (`rgba(29,185,84,.16)` with a `2px #1db954`
   right edge) shows how much of the track the unlocked clip covers; a faint
   `repeating-linear-gradient(90deg,#2e2e2e 0 2px,transparent 2px 7px)` reads as
   waveform ticks. Decorative — no audio analysis needed; width can simply be
   `stageMs / trackDurationMs`.
6. **Guessing terminal** — full width. A mono 10px `#555` section label
   `GUESSING TERMINAL` (`letter-spacing:.08em`), then the input row:
   `#161616`, border `1px #1db954` when focused, radius 8,
   `padding:12px 14px`, containing a green `>` prompt, the typed query in
   mono 14px, and an 8×17 solid `#1db954` block caret. This is the existing
   `<input placeholder="Search for a song">` restyled — keep it a real input;
   the caret/prompt are CSS decoration.
7. **Search results** — `gap:6px` column. Each row: 34px square thumb,
   two-line stack (track name 500 13px / artist mono 11px `#777`),
   `padding:9px 12px`, `#1a1a1a`, `1px #2a2a2a`, radius 8. Rows already
   prioritized by `prioritizePoolMatches` get a right-aligned `IN POOL` tag
   (mono 9px `#1db954`, `1px rgba(29,185,84,.4)`, radius 3) **and** a
   `1px #333` border. ⚠️ Gameplay note: `IN POOL` leaks the answer set —
   ship it only if that hint is intended, otherwise drop the tag and keep the
   reordering silent.
8. **History** — mono 12px `#888`, one line per attempt, above a `1px #1c1c1c`
   divider with a mono 10px `#555` `HISTORY` label. Wrong: red `✕` +
   `Track — Artist`; skip: grey `—` + `Skipped`. Stage duration in `#444` parens.
9. **Intro offset** — a `space-between` row, mono 11px `#555`: label
   `skip silent intro` and a small number input (`#161616`, `1px #2e2e2e`,
   radius 5, `#aaa`) plus `s` suffix. Backed by
   `getIntroOffsetMs` / `setIntroOffsetMs` in `src/introOffsets.js`.

### 1b — Stats panel
Purpose: lifetime stats for the logged-in Spotify account.
Layout: 420px card, `padding:24px`, `gap:18px` column. Header row with
`Stats` (700 16px) and a `✕` close on the right.
- A 2-column `gap:10px` grid of stat tiles (`#161616`, `1px #262626`, radius 8,
  `padding:16px`): big value (mono 700 28px — first tile `#1db954`, rest `#eee`)
  over a mono 10px `#777` `letter-spacing:.06em` caption.
  Tiles: **SONGS GUESSED** (`stats.totalGuessed`), **AVG CLIP NEEDED**
  (`stats.avgClipSeconds.toFixed(2)`+`s`, `—` when null), and a full-width
  **MOST LISTENED ARTIST** tile (`stats.mostListenedArtist`, value in
  700 20px sans not mono).
- **Guess distribution** — one horizontal bar per stage: mono 10px stage label
  (26px wide), a 16px-tall bar (radius 2; `#1db954`, `#2f6b45` for a low bucket,
  `#333` for zero), then the count in mono 10px `#666`.
  ⚠️ **Not yet in the data layer.** `src/stats.js` stores `clipSeconds` per round,
  so buckets are derivable (`clipSeconds*1000` → matching `STAGES` entry), but
  `getStatsSummary` must return them — add e.g. `byStage: {500:n, 2000:n, 8000:n, full:n}`.
  Losses have `clipSeconds: null` and belong in the `full` bucket or excluded — pick one.

### 1c — Reveal card
Purpose: end-of-round result, shown over the game (existing `.result-overlay`,
`rgba(0,0,0,.7)` scrim, centered).
Layout: 420px card, `padding:30px`, centered column, `gap:12px`.
- Title 700 26px — win: `Correct!` in `#1db954`; loss: `Out of guesses` in `#f88`.
- Win only: mono 500 12px `#1db954` subline `guessed in {winClipSeconds}s of audio`.
  Note the existing semantics — that number is clip length needed, not wall-clock.
- 110px album art square, radius 8.
- Track name 600 16px over artist mono 12px `#888`.
- Buttons row `gap:8px`: primary **New song** (`#1db954`, `#0b0b0b`, radius 999,
  `padding:10px 22px`) and ghost **Play full track** (`1px #3a3a3a`, `#aaa`).
Loss uses the same card, red title, no clip-time subline.

### 1d — Login + playlist switcher
**Login** — 420px card, `padding:40px 30px`, centered: 34px logo placeholder,
`neeshdle` 700 24px, a mono 12px `#777` tagline (max-width 250px)
"guess the song from your own playlist in as little audio as possible",
primary pill **Log in with Spotify** (600 14px, `padding:12px 26px`), and a
mono 11px `#555` note "Premium required for in-browser playback".
Auth errors render above the button in `#f88`.

**Playlist switcher** — 420px card, no padding, `overflow:hidden`.
A mono 10px `#666` `SWITCH PLAYLIST` header (`padding:14px 16px`, bottom border
`1px #1e1e1e`), then rows: 32px thumb + name 500 13px, `padding:11px 16px`,
`1px #1c1c1c` bottom borders. Active row has `background:#161616`, name in `#eee`,
and a right-aligned mono 9px `#1db954` `ACTIVE` tag; others `#ccc`.
Fed by `fetchMyPlaylists`; row click → `switchPlaylist(p.id)`.

## Interactions & Behavior
Unchanged from `src/App.jsx` — the mockup adds no new behavior:
- **Stats** button: `setStats(getStatsSummary(userId))` then toggle the panel.
- **Playlist** button: toggle the switcher; picking a row sets `activePlaylistId`,
  which re-runs the playlist load effect and resets the round.
- **Play**: `playStage({player, accessToken, deviceId, trackUri, targetMs, startOffsetMs})`.
  `targetMs` is `'full'` once the round is over, else `STAGES[unlockedIndex]`.
  Disabled while `busy`; errors surface in `#f88` beneath the actions row.
- **Search**: 300ms debounce on `query`, then `searchTracks`, results reordered by
  `prioritizePoolMatches(results, pool)`. `Searching…` hint while in flight.
- **Guess**: `isSameSong(track, currentTrack)`; on correct, records the round with
  `clipSeconds = currentStage/1000`; clears query and results either way.
- **Skip**: appends a `{kind:'skip'}` attempt; records a loss if it's the last stage.
- **New song**: `pickUnplayedTrack(pool, playedTrackIdsRef.current)` — tracks
  already played this page session are excluded (in-memory only, not persisted).
- No animations are specified. If added, keep them short (≤200ms) — suggested:
  slot border color transition, and the reveal card fading/scaling in.
- Responsive: the 640px column should collapse to full width with ~16px gutters
  under ~700px; slots shrink from 52px to ~44px. Not drawn in the mockup.

## State Management
Already implemented in `src/App.jsx` — reuse as is:
`attempts[]`, `busy`, `won` / `lost` / `over`, `failCount`, `unlockedIndex`,
`currentStage`, `query`, `searchResults`, `searchBusy`, `winClipSeconds`,
`offsetMs`, `showStats`, `stats`, `showSwitcher`, `activePlaylistId`,
`playlistInfo`, `myPlaylists`, `pool`, `currentTrack`, `userId`,
plus auth/player status from `useSpotifyAuth` / `useSpotifyPlayer`.
Only additions this spec implies: a per-stage breakdown in `getStatsSummary`
(see 1b) and a track duration for the progress bar fill (already on the
Spotify track object).

## Design Tokens
Colors (the `#1db954`/`#b91c1c`/`#f88` values come from `src/index.css`):
- page `#0b0b0b`, surface `#111`, raised `#161616`, row `#1a1a1a`, muted fill `#3a3a3a`
- borders `#1c1c1c` (subtle), `#262626`, `#2a2a2a`, `#333`, `#444`
- text `#eee`, secondary `#aaa`, tertiary `#888`, muted `#777`, faint `#666` / `#555`, ghost `#444`
- accent `#1db954`, accent dim `#2f6b45`, accent tint `rgba(29,185,84,.12–.16)`
- wrong `#b91c1c`, error text `#f88`
- scrim `rgba(0,0,0,.7)`

Typography: `Space Grotesk` for UI text (400/500/600/700),
`JetBrains Mono` for numerals, labels, and terminal text (400/500/700).
Both are placeholder choices — swap for the codebase's fonts if any exist.
Scale: 28 / 26 / 24 / 22 / 20 / 18 / 16 / 15 / 14 / 13 / 12 / 11 / 10 / 9px.
Section labels: mono 10px, `letter-spacing:.08em`, uppercase, `#555`.

Spacing: 2 / 3 / 5 / 6 / 8 / 9 / 10 / 12 / 14 / 16 / 18 / 22 / 24 / 30 / 34 / 40px.
Radius: 2 (bars) / 3 / 4 / 5 / 6 / 8 (cards, slots) / 12 (panels) / 999 (pills).
Shadow: only `0 0 0 4px rgba(29,185,84,.12)` on the current slot.
Fixed sizes: slot 52px, play button 74px, album art 110px, thumbs 30/32/34px,
progress bar 420×34, panel width 420px, main column 640px.

## Assets
- **None copied from the repo.** `public/icons.svg` was read: it contains only the
  unmodified Vite starter symbols (`bluesky-icon`, `discord-icon`,
  `documentation-icon`, `github-icon`, `social-icon`, `x-icon`) — nothing usable
  for a logo, play, skip, or close glyph. `public/favicon.svg` is likewise the
  default. So the mockup's logo is a **plain green square placeholder** and the
  play/skip/close/history marks are typed text (`PLAY`, `→`, `✕`, `—`).
  Replace all of these with a real icon set and logo — do not treat the square
  or the text glyphs as design intent.
- Album art and playlist thumbs come from the Spotify API
  (`images[0].url` / `track.album.images`). Striped grey blocks in the mockup are
  loading/empty placeholders.

## Files
- `screenshots/1a-main-round.png`, `1b-stats-panel.png`, `1c-reveal-card.png`,
  `1d-login-switcher.png` — rendered captures of each state (2x).
- `Neeshdle Mockup.dc.html` — the design reference (all four states, side by side).
  Open in a browser; `support.js` must sit next to it.
- `support.js` — runtime for the mockup file only. Not a deliverable.

Source files this spec was written against:
`src/App.jsx`, `src/index.css`, `src/config.js` (`STAGES`), `src/stats.js`,
`src/introOffsets.js`, `src/trackMatch.js`, `src/trackPicker.js`, `src/timing.js`.
